package okay.effects

/**
 * AN EFFECT'S NAME, a proper type, of its operations `L`: Scala 2 has no type alias whose result is a type
 * constructor, so a row is written by names — `*[Choose] + (State % Int)` — and taken as the constructor the names
 * make, `#L`.
 */
trait Effect { type L[X] }

/** the effect of the operations `F`, of no parameter: `*[Choose]#L` is `Choose` */
final abstract class *[F[_]] extends Effect { type L[X] = F[X] }

/** the effect `F` with its parameter `S`: `(State % Int)#L`, its operations `State[Int, X]` */
final abstract class %[F[_, _], S] extends Effect { type L[X] = F[S, X] }

/** the row `R` and the effect `E` after it, by their names: `(*[Choose] + (State % Int))#L` */
final abstract class +[R <: Effect, E <: Effect] extends Effect { type L[X] = Sum[R#L, E#L, X] }

/**
 * THE INTERFACE AS SCALA 2 WRITES IT: `Effectful`, and its rows by names. One precedence for all infix types: each
 * `%` in parentheses.
 *
 * {{{
 * type Row[X] = ((Reader % String) + (State % Int))#L[X]
 * def greet[R[_]](implicit r: In[(Reader % String)#L, R], s: In[(State % Int)#L, R]): Int ! R
 * }}}
 */
trait Effects extends Effectful {
  /** the names here too: an implementation imported gives them (`import Machine._`) */
  type %[F[_, _], S] = okay.effects.%[F, S]
  type *[F[_]] = okay.effects.*[F]
  type +[R <: Effect, E <: Effect] = okay.effects.+[R, E]
  /** THE ROW OF A NAME, applied — the one spelling both compilers read: `type F[X] = Row[*[Pure] + *[Face], X]`,
   * `Row[(Reader % String) + (State % Int), X]`. Here the name's `L` at `X`; in Scala 3 the name is the row already */
  type Row[N <: Effect, X] = N#L[X]
  /** a context bound: `def greet[R[_]: Has[(Reader % String)#L]#L]: Int ! R` */
  type Has[E[_]] = { type L[R[_]] = In[E, R] }

  /** the standard effects on this implementation: `import Machine.std._`. Final, a stable path to import from; made
   * by `newStd`, which an implementation may override with a `Std` of better handlers */
  final val std: Std[this.type] = newStd
  protected def newStd: Std[this.type] = new Std[this.type](this)
  /** delimited control changing answer types (`Delimited`), made by `newDelimited`: by default continuation-passing
   * over this implementation's programs; an implementation with continuations of its own overrides it */
  final val delimited: Delimited[this.type] = newDelimited
  protected def newDelimited: Delimited[this.type] = new Delimited.ByCps[this.type](this)

  /** a program's methods: `p.flatMap(f)`, `p.map(f)`, `p.into[S]` */
  implicit final class ProgramOps[A, R[_]](p: A ! R) {
    def flatMap[B](f: A => B ! R): B ! R = Effects.this.flatMap(p)(f)
    def map[B](f: A => B): B ! R = Effects.this.map(p)(f)
    def as[B](b: B): B ! R = map(_ => b)
    def andThen[B](q: => B ! R): B ! R = flatMap(_ => q)
    /** this program in a row of more effects */
    def into[S[_]](implicit s: Sub[R, S]): A ! S = embed[R, S, A](p)
  }
}
